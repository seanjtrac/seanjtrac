import { Injectable } from '@angular/core';
import { AngularFireAuth } from 'angularfire2/auth';
import * as firebase from 'firebase/app';
import AuthProvider = firebase.auth.AuthProvider;
import {User} from '../models/User';

@Injectable()
export class AuthenticationService {

	isAuthenticated: any =  null;

	constructor(public afAuth: AngularFireAuth) {

	}

 

   							/** signs out the user  **/
   logoutAService()
   {
   	this.afAuth.auth.signOut();
   }



  checkAuthStatusForApp()     // a method to check if the user is logged in or out. 
  {
		this.afAuth.auth.onAuthStateChanged(data=>{
			if (data)
			{
				this.isAuthenticated = true;
			}
			else
			{
				this.isAuthenticated = false;
			}
		});

		return this.isAuthenticated;
	}


}