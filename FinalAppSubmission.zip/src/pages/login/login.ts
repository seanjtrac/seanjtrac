import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';     // Toast Controller 
import { User } from "../../models/user"; 
import { AngularFireAuth } from 'angularfire2/auth';                  // imported Angular 
import { RegisterPage } from '../register/register';
import { HomePage } from '../home/home';
import { AuthenticationService } from '../../services/authentication.service';      // imported Authentication service for our login method below
import { IonicErrorHandler } from 'ionic-angular';






@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

	 user = {} as User;      // creates a user object
   userIsAuthenticated : boolean = false;        // creates a boolean variable to determine whether user is authenticated


  constructor(private afAuth: AngularFireAuth, private toast: ToastController,
  	public navCtrl: NavController, public navParams: NavParams, private ourAuth: AuthenticationService) {
   
    this.userIsAuthenticated = this.ourAuth.checkAuthStatusForApp();   // calls on the checkAuthStatusforApp from AuthenticationService.ts to determine if the user is logged in


  }

  checkAuthStatusForApp() 
  {
    this.afAuth.auth.onAuthStateChanged(data=>{
      if(data) 
      {
        this.userIsAuthenticated = true;                      // makes a call to see if the user is authenticated or not

      }
      else 
      {
        this.userIsAuthenticated = false;
      }
    });

  return this.userIsAuthenticated;
}

  ionViewWillLoad() {                                            

      
          this.toast.create({
              message: 'Welcome to Stockwatcher! Please register if it is your first time here.',     // when the page is loaded create a toaster message to ask them to register if they have not.
              duration: 4000  
                                           
       
        }).present();
    
    }



 async login(user: User)  { 
   try {
 	
 		const result = this.afAuth.auth.signInWithEmailAndPassword (user.email, user.password); 
                   //connected to the login html button
       				
               if (result && this.checkAuthStatusForApp() == true) {            // if we have a user with the right parameters and also are authenticated set root to the home page.


       				      this.navCtrl.setRoot(HomePage);        
                 this.afAuth.authState.subscribe(data => {                           
    if (data && data.email && data.uid) {                                  // checks if user is authenticated and matches all the criteria to to log in
          this.toast.create({
              message: 'Welcome to Stockwatcher',                            
             duration: 3000                   
        }).present();
    }          // gets rid of the back button when sending to home page.
     })

    

     
 }
}
         catch (err) {
           console.error(err);
             this.toast.create ({
                message: "Error invalid login",        // catches invalid log in errors and creates a toaster message 
                 duration: 3000
                   }).present(); 
 
}
	

}

register() {

	this.navCtrl.push(RegisterPage);  
       // takes the user to the register page upon click
}

}





