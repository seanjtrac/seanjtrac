import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';    // imported toaster for pop up messages
import { NasdaqPage } from '../nasdaq/nasdaq';
import { SandPPage} from '../sand-p/sand-p';
import { DowJonesPage} from '../dow-jones/dow-jones';
import { NysePage} from '../nyse/nyse';
import { AngularFireAuth } from 'angularfire2/auth';          // angular fire authentication import to make the call to firebase for user verification
import { RegisterPage } from '../register/register';    
import { AuthenticationService } from '../../services/authentication.service';    // our authentication service which we need to inject into this pages constructer
import { LoginPage } from '../login/login';



@IonicPage()
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  userIsAuthenticated : boolean = false;                          // created boolean variable to determine if user is authenticated 

  constructor(private afAuth: AngularFireAuth, private toast: ToastController,        // injected toast controller and angular fire authentication into the home class.
          public navCtrl: NavController, public navParams: NavParams, public ourAuth: AuthenticationService) {
                  this.userIsAuthenticated = this.ourAuth.checkAuthStatusForApp();                                        

  }


  




SignOut()
  {
    this.ourAuth.logoutAService();
    this.navCtrl.setRoot(LoginPage);
    // this.navCtrl.push(LoginPage);
  }


  
 


  public goToNasdaqPage()
  {
  	this.navCtrl.setRoot(NasdaqPage);  	                                    // Our navigation buttons.
  }

  public goToSP500Page()
  {

    this.navCtrl.setRoot(SandPPage);
  }

  public goToDowJonesPage()
  {
    this.navCtrl.setRoot(DowJonesPage);
  }

  public goToNYSEPage()
  {
    this.navCtrl.setRoot(NysePage);
  } 

  public goToRegisterPage() {
    this.navCtrl.setRoot(RegisterPage);
  }


}
