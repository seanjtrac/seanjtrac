import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../models/user'
import { AngularFireAuth } from "angularfire2/auth";
import { LoginPage } from '../login/login';

/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()         
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {

	user = {} as User;                                  // creates a user object

  constructor(private afAuth: AngularFireAuth,         // injected AngularFireauth here. 
  	public navCtrl: NavController, public navParams: NavParams, private toast: ToastController) {    // injection Toastcontroller for toast messages to work 
  }


  async register(user: User) {

	  	try {
	  		     const result = this.afAuth.auth.createUserWithEmailAndPassword(user.email, user.password); // tries to create a user with username and password
            console.log(result);
            



	  } 


	   catch(err) {
	   		console.error(err);
        // alert(e.message);
         var errorCode = err.code;
               var errorMessage = err.message;           // logs errors and tries to create a pop up message if we user hits an error during registration.
               console.log(errorMessage);
               this.toast.create ({
             message: errorMessage,
             duration: 3000
           }).present();
  	 }
      this.navCtrl.push(RegisterPage); 
     
  }


  public goToLoginPage(){                             // nav button to bring user back to log in page after registering.
    this.navCtrl.push(LoginPage);
   }
}

   





