import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SandPPage } from './sand-p';

@NgModule({
  declarations: [
    SandPPage,
  ],
  imports: [
    IonicPageModule.forChild(SandPPage),
  ],
})
export class SandPPageModule {}
