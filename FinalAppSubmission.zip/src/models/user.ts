export interface User {          // template for user consisting of e-mail and password, will be used in the login and register processes.


	email: string; 
	password: string;
}